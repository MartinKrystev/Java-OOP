package com.company.WorkingWithAbstraction.Exercise.P04TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW

}
