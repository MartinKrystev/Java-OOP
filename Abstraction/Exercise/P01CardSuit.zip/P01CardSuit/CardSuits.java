package com.company.WorkingWithAbstraction.Exercise.P01CardSuit;

public enum CardSuits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
